import './ConceptsTab.css';

function ConceptsTab() {
  const concepts = [
    { icon: '🔗', title: 'APIs & Microservices', desc: 'APIs allow different software systems to communicate, while microservices break down applications into smaller, independent services for easier scaling and maintenance.' },
    { icon: '🗄️', title: 'Databases', desc: 'Databases store, organize, and retrieve data efficiently. SQL databases (like PostgreSQL) use structured schemas, while NoSQL (like MongoDB) offer flexibility for unstructured data.' },
    { icon: '🔒', title: 'Authentication & Security', desc: 'Security ensures only authorized users access data. Techniques include OAuth, JWT, encryption, and regular security audits.' },
    { icon: '⚡', title: 'Performance & Scalability', desc: 'Performance tuning and scalability strategies (like caching, load balancing, and horizontal scaling) ensure systems handle growth and high traffic.' },
    { icon: '🚀', title: 'DevOps & Deployment', desc: 'DevOps automates testing, integration, and deployment, enabling rapid, reliable releases and infrastructure as code.' },
  ];
  return (
    <section className="concepts-tab">
      <h2>Key Server Side Concepts</h2>
      <div className="concepts-list">
        {concepts.map((c) => (
          <div className="concept-card" key={c.title}>
            <span className="concept-icon">{c.icon}</span>
            <h4>{c.title}</h4>
            <p>{c.desc}</p>
          </div>
        ))}
      </div>
      <div className="advanced-section">
        <h3>Advanced Concepts</h3>
        <ul>
          <li><strong>Serverless Architectures:</strong> Run code without managing servers, using platforms like AWS Lambda and Azure Functions.</li>
          <li><strong>Event-Driven Systems:</strong> React to events in real time, enabling scalable, loosely coupled applications.</li>
          <li><strong>Observability & Monitoring:</strong> Use tools like Prometheus, Grafana, and ELK stack to monitor, trace, and debug distributed systems.</li>
          <li><strong>Edge Computing:</strong> Process data closer to users for lower latency and better performance.</li>
        </ul>
      </div>
    </section>
  );
}

export default ConceptsTab; 