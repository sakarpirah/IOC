import GraphComparison from './GraphComparison';
import './ComparisonTab.css';

function ComparisonTab() {
  return (
    <section className="comparison-tab">
      <h2>Framework & Database Comparisons</h2>
      <GraphComparison />
    </section>
  );
}

export default ComparisonTab; 