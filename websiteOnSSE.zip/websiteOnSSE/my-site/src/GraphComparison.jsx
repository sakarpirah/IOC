import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const frameworkData = [
  { name: 'Node.js', popularity: 85 },
  { name: 'Django', popularity: 70 },
  { name: 'Spring Boot', popularity: 65 },
  { name: 'Express', popularity: 60 },
  { name: 'Flask', popularity: 50 },
];

const dbData = [
  { name: 'PostgreSQL', value: 40 },
  { name: 'MongoDB', value: 30 },
  { name: 'MySQL', value: 20 },
  { name: 'Redis', value: 10 },
];

const COLORS = ['#1e3c72', '#2a5298', '#61dafb', '#e3eaf6'];

function GraphComparison() {
  return (
    <div className="graph-comparison">
      <div className="graph-section">
        <h3>Framework Popularity</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={frameworkData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="popularity" fill="#2a5298" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="graph-section">
        <h3>Database Usage</h3>
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie data={dbData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
              {dbData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Legend />
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default GraphComparison; 