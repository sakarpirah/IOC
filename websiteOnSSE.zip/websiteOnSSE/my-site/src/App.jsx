import Dashboard from './Dashboard';
import './App.css';

function App() {
  return <Dashboard />;
}

export default App;
