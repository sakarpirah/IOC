import Tabs from './Tabs';
import './Dashboard.css';

function Dashboard() {
  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1>Server Side Engineering Dashboard</h1>
        <p>Explore concepts, technologies, and comparisons in backend development</p>
      </header>
      <Tabs />
    </div>
  );
}

export default Dashboard; 