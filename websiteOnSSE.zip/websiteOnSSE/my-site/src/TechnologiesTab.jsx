import './TechnologiesTab.css';

function TechnologiesTab() {
  const techs = [
    { logo: "🟩", name: "Node.js", desc: "Node.js is a JavaScript runtime built on Chrome's V8 engine, enabling fast, scalable network applications with non-blocking I/O." },
    { logo: "⚛️", name: "Express", desc: "Express is a minimalist web framework for Node.js, providing robust features for building APIs and web apps." },
    { logo: "🐍", name: "Python", desc: "Python is a versatile, high-level language popular for backend development, data science, and automation." },
    { logo: "🌱", name: "Django", desc: "Django is a high-level Python web framework that encourages rapid development and clean, pragmatic design." },
    { logo: "☕", name: "Java", desc: "Java is a robust, object-oriented language widely used for enterprise-scale backend systems." },
    { logo: "🌼", name: "Spring Boot", desc: "Spring Boot simplifies Java backend development with convention-over-configuration and production-ready features." },
    { logo: "🐘", name: "PostgreSQL", desc: "PostgreSQL is an advanced open-source relational database known for reliability, feature robustness, and performance." },
    { logo: "🍃", name: "MongoDB", desc: "MongoDB is a NoSQL database designed for flexible, scalable storage of unstructured data." },
    { logo: "🐳", name: "Docker", desc: "Docker enables containerization, allowing applications to run consistently across environments." },
    { logo: "☁️", name: "AWS", desc: "Amazon Web Services (AWS) provides scalable cloud infrastructure and services for modern applications." }
  ];
  return (
    <section className="technologies-tab">
      <h2>Popular Backend Technologies</h2>
      <div className="tech-cards-grid">
        {techs.map((t) => (
          <div className="tech-card" key={t.name}>
            <span className="tech-logo">{t.logo}</span>
            <h4>{t.name}</h4>
            <p>{t.desc}</p>
          </div>
        ))}
      </div>
      <div className="emerging-section">
        <h3>Emerging Technologies</h3>
        <ul>
          <li><strong>GraphQL:</strong> A query language for APIs that enables clients to request exactly the data they need.</li>
          <li><strong>Rust:</strong> A systems programming language gaining traction for safe, high-performance backend services.</li>
          <li><strong>WebAssembly:</strong> Enables high-performance code (from languages like C, C++, Rust) to run in the browser and on the server.</li>
          <li><strong>Deno:</strong> A secure runtime for JavaScript and TypeScript, created by the original Node.js author.</li>
          <li><strong>Bun:</strong> A fast JavaScript runtime, bundler, and package manager designed for modern web development.</li>
        </ul>
      </div>
    </section>
  );
}

export default TechnologiesTab; 