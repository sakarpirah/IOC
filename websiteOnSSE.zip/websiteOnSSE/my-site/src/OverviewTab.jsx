import './OverviewTab.css';

function OverviewTab() {
  return (
    <section className="overview-tab">
      <div className="overview-hero">
        <h2>Welcome to Server Side Engineering</h2>
        <p>
          Server Side Engineering (SSE) is the backbone of modern web and mobile applications. It ensures data is processed, stored, and delivered securely and efficiently, enabling seamless user experiences across the globe.
        </p>
      </div>
      <div className="overview-content">
        <h3>Why is SSE Important?</h3>
        <ul>
          <li>Handles business logic and data management</li>
          <li>Secures sensitive information and user data</li>
          <li>Scales to support millions of users</li>
          <li>Integrates with third-party services and APIs</li>
        </ul>
        <div className="examples">
          <h3>Real-World Examples</h3>
          <ul>
            <li><strong>E-commerce:</strong> Processing orders, managing inventory, and handling payments securely.</li>
            <li><strong>Social Media:</strong> Managing user profiles, posts, and real-time notifications.</li>
            <li><strong>Streaming Services:</strong> Delivering video/audio content efficiently to millions of users.</li>
            <li><strong>Banking Apps:</strong> Ensuring secure transactions and data privacy.</li>
          </ul>
        </div>
        <div className="evolution">
          <h3>The Evolution of Server Side Engineering</h3>
          <p>
            Server-side engineering has evolved from simple CGI scripts in the 1990s to today's complex, distributed microservices architectures. Modern SSE leverages cloud computing, containerization, and DevOps practices to deliver scalable, reliable, and secure applications. The focus has shifted from monolithic servers to highly available, globally distributed systems that can handle massive loads and provide seamless user experiences.
          </p>
        </div>
      </div>
    </section>
  );
}

export default OverviewTab; 