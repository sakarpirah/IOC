import { useState } from 'react';
import OverviewTab from './OverviewTab';
import ConceptsTab from './ConceptsTab';
import TechnologiesTab from './TechnologiesTab';
import ComparisonTab from './ComparisonTab';
import ResourcesTab from './ResourcesTab';
import './Tabs.css';

const tabList = [
  { label: 'Overview', component: <OverviewTab /> },
  { label: 'Concepts', component: <ConceptsTab /> },
  { label: 'Technologies', component: <TechnologiesTab /> },
  { label: 'Comparison', component: <ComparisonTab /> },
  { label: 'Resources', component: <ResourcesTab /> },
];

function Tabs() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <div className="tabs-container">
      <nav className="tabs-nav">
        {tabList.map((tab, idx) => (
          <button
            key={tab.label}
            className={activeTab === idx ? 'tab-btn active' : 'tab-btn'}
            onClick={() => setActiveTab(idx)}
          >
            {tab.label}
          </button>
        ))}
      </nav>
      <div className="tab-content">
        {tabList[activeTab].component}
      </div>
    </div>
  );
}

export default Tabs; 