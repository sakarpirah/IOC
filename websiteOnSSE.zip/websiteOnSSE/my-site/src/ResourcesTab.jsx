import './ResourcesTab.css';

function ResourcesTab() {
  const links = [
    { url: 'https://developer.mozilla.org/en-US/docs/Learn/Server-side', label: 'MDN: Server-side website programming' },
    { url: 'https://roadmap.sh/backend', label: 'Backend Developer Roadmap' },
    { url: 'https://www.digitalocean.com/community/tutorial_series/server-side-programming', label: 'DigitalOcean: Server-Side Programming' },
    { url: 'https://www.freecodecamp.org/news/tag/backend/', label: 'freeCodeCamp: Backend Articles' },
    { url: 'https://backend.cafe/', label: 'Backend Cafe: Community & Resources' },
  ];
  return (
    <section className="resources-tab">
      <h2>Further Reading & Resources</h2>
      <ul className="resources-list">
        {links.map((l) => (
          <li key={l.url}>
            <a href={l.url} target="_blank" rel="noopener noreferrer">{l.label}</a>
          </li>
        ))}
      </ul>
    </section>
  );
}

export default ResourcesTab; 